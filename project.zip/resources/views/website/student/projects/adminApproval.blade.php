@extends('website.layout')
@section('content')

<div class="container text-center">

  
    </div>
    <div class="col-md-9"></div>
   </div>
    <div class="row">
        <div class="col-md-1"></div>
        <div class="col-md-9 m-5 ">
            <div class="row justify-content-center">
                <div class="col-md-4 offset-md-1  m-4"  >
                    <img src="{{asset('admin_approval.png')}}" class="card-img-top" alt="...">
                    <br>
                    <br>
                    <h2 style="color: #00264D;">Wait for Admin Approval</h2>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection