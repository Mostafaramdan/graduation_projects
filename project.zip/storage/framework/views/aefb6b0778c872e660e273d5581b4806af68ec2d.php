<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>">
</head>
<body>
<nav class="navbar bg-light">
  <div class="container-fluid "style="margin-left:29%">
    <a class="navbar-brand " href="#" >
        <img src="<?php echo e(asset('logo.png')); ?>" alt="" width="90" height="82" >
        <span style="font-size:30px">
            Higher Technological Institute
        </span>
    </a>
  </div>
</nav>
<script src="<?php echo e(asset('app.js')); ?>"></script>
</body>
</html><?php /**PATH /home/mostafa/projects/institute-freeLancer/resources/views/login.blade.php ENDPATH**/ ?>