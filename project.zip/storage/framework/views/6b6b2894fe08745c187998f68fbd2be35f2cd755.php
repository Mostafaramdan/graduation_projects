<section class="content-header">
    <div class="container-fluid row d-flex justify-content-center ">
        <?php if(session('success')): ?>
            <div class="alert alert-success col-sm-6 text-center" role="alert">
                <?php echo session('success'); ?>

            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger col-sm-6 text-center" role="alert">
                <?php echo session('error'); ?>

            </div>
        <?php endif; ?>
    </div>
</section><?php /**PATH /home/mostafa/projects/institute-freeLancer/resources/views/website/session.blade.php ENDPATH**/ ?>