<?php $__env->startSection('content'); ?>

<div class="container text-center">
    <div class="col-md-9"></div>
   </div>
    <div class="row">
        <div class="col-md-11 m-5 ">
            <div class="row justify-content-center">
                    <div class="d-flex align-items-center shadow-lg p-3 mb-5 bg-body rounded">
                        <div class="flex-grow-1 ms-3 " style=" color:#00264d" >
                            <h3>project name</h3>
                            <br>
                            <br>
                            <strong style="color:#898a8d;">
                                This is some content from a media component. You can replace this with any content and adjust it as needed.
                                This is some content from a media component. You can replace this with any content and adjust it as needed.
                                This is some content from a media component. You can replace this with any content and adjust it as needed.
                                This is some content from a media component. You can replace this with any content and adjust it as needed.
                                This is some content from a media component. You can replace this with any content and adjust it as needed.
                            </strong> 
                            <br>
                            <br>
                            <h6>
                                <i class="fa fa-paperclip"></i>
                                Attached File : Project Porposal.pdf
                                <i class="fa-solid fa-arrow-down-to-bracket"></i>
                            </h6>
                            <br>
                            <br>
                            <h4>
                                Your Team IDs
                            </h4>
                            <ul class="list-group">
                                <li class="">Ahmed Safwat Saber  -  42017011</li>
                                <li class="">Moaz Abdelaty Ahmed    -   42017132</li>
                                <li class="">Ahmed Mohamed Selim    -   42018028</li>
                                <li class="">Khaled Hakim Ezzat    -   42018088</li>
                                <li class="">Hossam Shaban Ahmed    -   42019070</li>
                                <li class="">Mohamed Salah Abdelmoneam    -   42019153</li>
                            </ul>
                            <br>
                            <br>
                            <h4>
                                supervisor doctor name : <a style="color:#d63384">Doctor Roshdy</a>
                            </h4>
                            <br>
                            <br>
                            <div class="row">
                                <div class="col-md-9 offset-md-3">

                                    <button class="btn  w-25  border border-5 " style="color:#fff; background-color:#00264d">Approve</button>
                                    <button class="btn btn-light w-25 border border-5 border-primary">Decline</button>

                                </div>
                            </div>
                        </div>
                    </div>
              
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mostafa/projects/institute-freeLancer/resources/views/website/projects/show.blade.php ENDPATH**/ ?>