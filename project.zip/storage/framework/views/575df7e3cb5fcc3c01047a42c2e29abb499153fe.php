<?php $__env->startSection('content'); ?>

<div class="container text-center">

  
    </div>
    <div class="col-md-9"></div>
   </div>
    <div class="row">
        <div class="col-md-1"></div>
        <div class="col-md-9 m-5 ">
            <div class="row justify-content-center">
                <div class="col-md-4">
                    <div class="card" style="width: 18rem;padding:10%">
                        <img  style="height:200px"src="<?php echo e(asset('Pending_Projects.png')); ?>" class="card-img-top" alt="...">
                        <div class="card-body">
                            
                            <a href="<?php echo e(route('project.pending')); ?>" > <h5 class="card-title">Pending Projects</h5></a>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 offset-md-3 ">
                    <div class="card " style="width: 18rem;padding:10%">
                        <img  style="height:200px" src="<?php echo e(asset('idea.png')); ?>" class="card-img-top" alt="...">
                        <div class="card-body">
                            <a href="<?php echo e(route('project.create')); ?>" > <h5 class="card-title">Add New Projects</h5></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mostafa/projects/institute-freeLancer/resources/views/website/admin/projects/main.blade.php ENDPATH**/ ?>