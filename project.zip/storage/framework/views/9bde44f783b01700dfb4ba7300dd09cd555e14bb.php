<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        /* It is the starting/main point of displaying different payment sections like Saved card, New card, Payment button, etc */
        .payment-container {
            width: 500px; /* Width is defined to make sure everything is being rendered within the width */
            margin: 0 auto; /* It helps to render payment container in the center of the page */
        }

        /* Checkbox is required to select New card container & Radio box is required to select any EMI Plans if applicable */
        .payment-container input[type=checkbox], input[type=radio] {
            box-sizing: border-box; /* An explicit way to tell browser to render in the border-box layout to layout elements. */
            padding: 0;
        }

        /* It is parent container for new card where it includes controls like card number along with card logo, card holder name, card expiry & CVV */
        .new-card-box {
            padding: 10px 16px;
            background: #fff;
            border: 1px solid #e6ebf3;
            box-sizing: border-box;
            border-radius: 4px;
        }


        /* It is the combination of entering card number and display respective card logo beside of card number */
        .card-number-input-box {
            display: -ms-flexbox;
            display: flex;
            -ms-flex-pack: start;
            justify-content: flex-start;
            -ms-flex-align: baseline;
            align-items: baseline;
        }

        /* Box class is a generic class used for all input box layout controls like card number, card holder name, card expiry & CVV */
        .box {
            cursor: text;
            font-size: 14px;
            width: 100%;
            padding: 10px;
            background: #fff;
            box-sizing: border-box;
            border-radius: 4px;
            height: 44px;
            border: 1px solid #ccc;
            padding: 0;
            display: flex;
            align-items: center;
            padding-left: 10px;
        }

        /* The box-focus will triggered when we clicks or taps on any input control or selects it with the keyboard's (Tab) key  */
        .box-focus {
            border: 2px solid #3866DF !important;
        }

        /* The box-error will display input box control with border and box-shadow whenever we have error for such input control */
        .box-error {
            border: 2px solid #ca5e58 !important;
            box-shadow: 0 0 5px #ca5e58 !important;
        }

        /* Error message block is to display whenever we enter incorrect fields like card number, card holder name, card expiry & CVV. */
        .error-msg {
            color: red;
            margin-top: 8px;
            margin-left: 2px;
        }

        /* Parent container for both Expiry & CVV controls */
        .cvv-expiry-container-box {
            justify-content: space-evenly;
            display: flex;
        }

        /* Child container to show the Card Expiry control  */
        .expiry-container-box {
            margin-right: 10px; /* It is required to provide space between Expiry & CVV sections */
            width: 42%;
            flex: 40;
        }

        /* Child container to show the Card CVV control  */
        .cvv-container-box {
            flex: 30;
            -ms-flex: 30;
            width: 42%;
        }

        /* Payment button */
        #pay-btn {
            width: 100%; /* It renders the Payment button to make it occupy to 100% */
        }
    </style>
</head>
<body>
<div id="payment-box-container">
  <div id="saved-cards-container"></div>  <!-- JS library will render saved cards in this container. In each saved card item only the cvv element will be hosted on noon payments, rest will be managed by merchant. -->
  <div id="use-new-card-container"></div> <!-- JS library will render new card selection radio button if there are saved card and new card is allowed. -->
  <div id="new-card-container"> <!-- JS library will render new card fields. -->
    <label for="card-number">Card Number</label>  <!-- This is a for hosted frame to collect card number. -->
	<div id="card-number-frame-container"></div>  <!-- JS library will render hosted card number frame in this container. -->
	<label for="card-holder-name">Card Holder Name</label>
	<div id="card-holder-frame-container"></div>  <!-- JS library will render hosted card holder name frame in this container. -->
    <label for="card-expiry">Expiry</label>
	<div id="card-expiry-frame-container"></div>  <!-- JS library library will render hosted card expiry frame in this container. -->
    <label for="cvv">CVV</label>
	<div id="cvv-frame-container"></div>  <!-- JS library will render hosted card cvv frame in this container. -->
	<div id="save-new-card-container"></div>  <!-- JS library will render save new card check box in this container. -->
  </div>
  <div id="emi-bank-plans"></div> <!-- JS library will render applicable EMI plans emitted by noonPayments.events.emiDataChanged event. -->
  <div id="pay-btn">Pay Now</div> <!-- JS library need a reference to this button (event fired on this button click). -->
</div>
    <script src="https://cdn.noonpayments.com/script/v1/noonpayments.js"></script>
    <script >
       var config = {
            orderUrlReference: "$postUrl",
            containers: {
                savedCards: {
                container: new noonPayments.defaultContainerAdaptor(document.getElementById("saved-cards-container"))
                },
                newCardPaymentSelection: {
                container: new noonPayments.defaultContainerAdaptor(document.getElementById("use-new-card-container"))
                },
                cardNumber: {
                container: new noonPayments.defaultContainerAdaptor(document.getElementById("use-new-card-container"))
                },
                cardHolderName: {
                container: new noonPayments.defaultContainerAdaptor(document.getElementById("card-holder-frame-container"))
                },
                expiryDate: {
                container: new noonPayments.defaultContainerAdaptor(document.getElementById("card-expiry-frame-container"))
                },
                cvv: {
                container: new noonPayments.defaultContainerAdaptor(document.getElementById("card-cvv-frame-container"))
                },
                saveCard: {
                container: new noonPayments.defaultContainerAdaptor(document.getElementById("save-new-card-container"))
                },
                payButton: {
                button: new noonPayments.defaultButtonAdaptor(document.getElementById("pay-btn"))
                }
            },
        };

        //create transaction object & register events
        var transaction = new noonPayments.newTransaction(config);  // will be emitted once transaction is complete.
        transaction.on(noonPayments.events.transactionCompleted, function (data) { });  // will be emitted if there are any validation errors.
        transaction.on(noonPayments.events.validationError, function (error) { });  // will be emitted if input focus changed of a field.
        transaction.on(noonPayments.events.inputFocusChanged, function (data) { }); // will be emitted if input validation changed of a field.
        transaction.on(noonPayments.events.inputValidationChanged, function (data) { });  // will be emitted if card brand is changed while user is entering card number.
        transaction.on(noonPayments.events.cardBrandChanged, function (data) { });  // will be triggered once user click on pay button and transaction processing is started.
        transaction.on(noonPayments.events.transactionProcessingStarted, function () { });  // will be triggered if payment instrument is changed. i.e. saved card to new card or different saved card.
        transaction.on(noonPayments.events.paymentSelectionChanged, function (data) { }); //will be triggerd if payment form validation status changed.
        transaction.on(noonPayments.events.formValidationStatusChanged, function (isValidForm) { });  // will be triggerd where there is change (bin changed) in applicable EMI banks and plans.
        transaction.on(noonPayments.events.emiDataChanged, function (emiBanks) { }); //This will initiate transaction and render/load hosted frames.
        transaction.prepare().then(function (data) { }, function (error) { });

    </script>
</body>
</html><?php /**PATH /home/mostafa/projects/institute-freeLancer/resources/views/payment.blade.php ENDPATH**/ ?>