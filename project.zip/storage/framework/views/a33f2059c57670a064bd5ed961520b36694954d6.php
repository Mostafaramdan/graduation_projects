<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <nav aria-label="breadcrumb">
    </nav>
    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-9 shadow-lg p-3 mb-5 bg-body rounded m-3">
            
            <form class="m-5">
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Project Name</label>
                    <input type="text" placeholder="Project Name" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                </div>

                <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">Project Description</label>
                    <textarea  placeholder="Project Description" class="form-control" id="exampleInputPassword1"></textarea>
                </div>

                <div class="mb-3">
                    <label for="formFile" class="form-label">Add Project Porposal</label>
                    <input class="form-control" type="file" id="formFile">
                </div>
                <div class="mb-3 shadow p-3 mb-5 bg-body rounded">
                    <label for="groupID" class="form-label">group ID</label>
                    <button class="btn btn-success ml-3" style="margin-left:10%"> add new member</button>
                    
                    <?php for($i=1 ;$i < 5 ; $i++): ?>
                        <div class="row m-1 ">
                            <div class="col-9">
                                <input type="text" placeholder="student ID" class="form-control" id="groupID" aria-describedby="groupID">
                            </div>
                            <div class="col-3">
                                <button class="btn btn-danger"> delete</button>
                            </div>
                        </div>
                    <?php endfor; ?>
                </div>
                <div class="mb-3">
                    <label for="supervisor" class="form-label">select Supervisor Doctor Name</label>
                    <?php
                        $doctors= [
                            'أ. د/رشدي فاروق  ',
                            'أ. د/يسريه ابو النجا ',
                            'د/رانيا رجب حسين',
                            'د/ساره سليمان',
                            'د/دينا عوني',
                            'د/شيماء عبدالله'
                            ];
                    ?>
                    <select class="form-control" id="supervisor" >
                        <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($doctor); ?>"><?php echo e($doctor); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                </div>
               
                
                <button type="submit" class="btn btn-primary ">submit </button>
            </form>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mostafa/projects/institute-freeLancer/resources/views/website/projects/create.blade.php ENDPATH**/ ?>