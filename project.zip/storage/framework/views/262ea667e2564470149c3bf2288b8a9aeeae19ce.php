<?php
$totalPages = ceil($paginator->total() / $paginator->perPage());
?> 
<nav aria-label="Page navigation example">
    <ul class="pagination justify-content-center">
        <li class="page-item">
            <a class="page-link" href="?page=<?php echo e($paginator->currentPage()-1 < 1? 1:$paginator->currentPage()-1); ?>" aria-label="Previous">
            <span aria-hidden="true">&laquo;</span>
            </a>
        </li>
        <?php for($i=1; $i<=$totalPages ;$i++): ?>
            <?php if($totalPages>5): ?>
                <?php if( $i == 1): ?>	    
                    <li class="page-item <?php if($i == $paginator->currentPage()): ?> active <?php endif; ?>" ><a class="page-link"  href="?page=1">1</a></li>
                <?php endif; ?>

                <?php if($i ==2 && $paginator->currentPage() >2 ): ?>
                    <li class="page-item "><a class="page-link" href="#" >...</a></li>
                <?php endif; ?>
                
                <?php if( $i != 1 &&  $i != $totalPages && ($i == $paginator->currentPage() ||$i == $paginator->currentPage()+1 ||  $i == $paginator->currentPage()-1) ): ?>
                <li class="page-item <?php if($i == $paginator->currentPage()): ?> active <?php endif; ?>"><a class="page-link" href="?page=<?php echo e($i); ?>" ><?php echo e($i); ?></a></li>
                <?php endif; ?>

                <?php if(  $i+1 > $totalPages && $paginator->currentPage()+1 < $totalPages): ?>
                    <li class="page-item"><a class="page-link" href="#">...</a></li>
                <?php endif; ?>
                
                <?php if( $i == $totalPages && $paginator->currentPage()!= $totalPages ): ?>	    
                    <li class="page-item <?php if($i == $paginator->currentPage()): ?> active <?php endif; ?>"><a class="page-link" href="?page=<?php echo e($totalPages); ?>" >الأخير</a></li>
                <?php endif; ?>
                <?php if( $i == $totalPages && $paginator->currentPage()== $totalPages ): ?>	    
                    <li class="page-item  <?php if($i == $paginator->currentPage()): ?> active <?php endif; ?>"><a class="page-link" href="?page=<?php echo e($totalPages); ?>" ><?php echo e($i); ?></a></li>
                <?php endif; ?>
            <?php else: ?>
                <li class="page-item <?php if($i == $paginator->currentPage()): ?> active <?php endif; ?>"><a class="page-link  " href="?page=<?php echo e($i); ?>" ><?php echo e($i); ?></a></li>
            <?php endif; ?>
        <?php endfor; ?>    
        <li class="page-item">
            <a class="page-link" href="?page=<?php echo e($paginator->currentPage()+1 > $totalPages? $totalPages :$paginator->currentPage()+1); ?>" aria-label="Next">
            <span aria-hidden="true">&raquo;</span>
            </a>
        </li>
    </ul>
</nav><?php /**PATH /home/mostafa/projects/institute-freeLancer/resources/views/website/paginator.blade.php ENDPATH**/ ?>