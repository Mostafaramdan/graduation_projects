<?php $__env->startSection('content'); ?>

<div class="container text-center">

  
    </div>
    <div class="col-md-9"></div>
   </div>
    <div class="row">
        <div class="col-md-1"></div>
        <div class="col-md-9 m-5 ">
            <div class="row justify-content-center">
                <div class="col-md-4 offset-md-1  m-4"  >
                    <img src="<?php echo e(asset('admin_approval.png')); ?>" class="card-img-top" alt="...">
                    <br>
                    <br>
                    <h2 style="color: #00264D;">Wait for Admin Approval</h2>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mostafa/projects/institute-freeLancer/resources/views/website/student/projects/adminApproval.blade.php ENDPATH**/ ?>