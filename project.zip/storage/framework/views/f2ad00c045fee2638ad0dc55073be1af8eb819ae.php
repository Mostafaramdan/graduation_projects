<?php $__env->startSection('content'); ?>

<div class="container text-center">
    <div class="col-md-9"></div>
   </div>
    <div class="row">
        <div class="col-md-11 m-5 ">
            <div class="row justify-content-center">
                <div class="d-flex align-items-center shadow-lg p-3 mb-5 bg-body rounded">
                    <div class="flex-grow-1 ms-3 " style=" color:#00264d" >
                    <div class="accordion-body">
                        <br>
                        <h3> <?php echo e($project->name); ?></h3>
                        <br>

                        <p>Project Porposal:  <?php echo e($project->description); ?></p>
                        <p>
                            
                        </p>
                        <br>
                        <h6 >
                                <i class="fa fa-paperclip"></i>
                                Attached File : <?php echo e($project->proposal); ?>

                                <i class="fa-solid fa-download " style="margin-left:20px;cursor:pointer" onClick="location.href='<?php echo e(asset($project->proposal)); ?>'"></i>
                            </h6>
                            <br>
                            <h4>
                                Your Team IDs
                            </h4>
                            <ul class="list-group">
                                
                                <?php $__currentLoopData = $project->members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li >
                                        <h4 style="color: #303030; "><?php echo e($member->name.'     -    '. $member->student_ID); ?></h4>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <br>
                            <br>
                            <h4>
                                supervisor doctor name : <a style="color:#d63384"><?php echo e($project->doctor->name); ?></a>
                            </h4>
                                <div class="row">
                                    <div class="col-md-9 offset-md-3">

                                        <a class="btn  w-25  border border-5 " href="<?php echo e(route('project.changeStatus',$project->id)); ?>?status=accept" style="color:#fff; background-color:#00264d">Approve</a>
                                        <button class="btn btn-light w-25 border border-5 border-primary" href="<?php echo e(route('project.changeStatus',$project->id)); ?>?status=decline">Decline</button>

                                    </div>
                                </div>
                        </div>
                    </div>
                </div>              
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mostafa/projects/institute-freeLancer/resources/views/website/admin/projects/show.blade.php ENDPATH**/ ?>