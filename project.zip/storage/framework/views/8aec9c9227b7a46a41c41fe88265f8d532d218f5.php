<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(config('app.name')); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('style1.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('updates.css')); ?>">
    <script src="<?php echo e(asset('jquery.js')); ?>" ></script>
    <link rel="stylesheet" href="<?php echo e(asset('fontawesome/css/all.css')); ?>" />
</head>
<body>
<nav class="navbar navbar-expand-lg bg-light fw-bold" >
    <div class="container-fluid">
        <a class="navbar-brand " href="#" >
            <img src="<?php echo e(asset('logo.png')); ?>" alt="" width="90" height="82" >
            <span style="font-size:30px">
                <?php echo e(config('app.name')); ?>

            </span>
        </a>
        <div class="collapse navbar-collapse" style="margin-left:20%" id="navbarSupportedContent">
            <ul class="navbar-nav ">
                <li class="nav-item">
                    <a class="nav-link <?php echo e(Route::currentRouteNamed('project.main') ? 'active' : ''); ?>" aria-current="page" href="<?php echo e(route('project.main')); ?>">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(Route::currentRouteNamed('project.myProjects') ? 'active' : ''); ?>" href="<?php echo e(route('project.myProjects')); ?>">Your Projects</a>
                </li>
                <li class="nav-item">
                    <?php if(AuthLogged()->isAdmin()): ?>
                        <a class="nav-link <?php echo e(Route::currentRouteNamed('project.pending') ? 'active' : ''); ?>" href="<?php echo e(route('project.pending')); ?>">pending Projects</a>
                    <?php else: ?>
                        <a class="nav-link <?php echo e(Route::currentRouteNamed('project') ? 'active' : ''); ?>" href="<?php echo e(route('project.index')); ?>">available Projects</a>
                    <?php endif; ?>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(Route::currentRouteNamed('project.create') ? 'active' : ''); ?>" href="<?php echo e(route('project.create')); ?>">Add New Project</a>
                </li>
                <li class="nav-item ">
                    <a class="nav-link" onClick="$('#logout-form').submit()" href="#">logout</a>
                    <form id="logout-form" action="<?php echo e(route('website.logout')); ?>" method="POST" >
                        <?php echo csrf_field(); ?>
                        <input   type="submit" class="d-none" href="#">
                    </form>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php echo $__env->yieldContent('content'); ?>
<script src="<?php echo e(asset('app.js')); ?>"></script>
</body>
</html><?php /**PATH /home/mostafa/projects/institute-freeLancer/resources/views/website/layout.blade.php ENDPATH**/ ?>