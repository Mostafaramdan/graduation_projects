<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(config('app.name')); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>">
</head>
<body>
<div class="container-fluid">
    <nav aria-label="breadcrumb">
    </nav>
    <div class="row ">
        <div class="col-md-3"></div>
        <div class="col-md-7 bg-light m-3 shadow-lg p-3 mb-5 bg-body rounded" style="margin-top:10% !important">
            <h4 style="color:#00264d;margin-left:37%;margin-top:10%" >Student Login</h4>
            <div class="mb-5" style="margin:20px;margin-left:32%">
                <img src="<?php echo e(asset('logo.png')); ?>" alt="logo" height="250" width="250" >
            </div>
            <form class="m-4" action="<?php echo e(route('post.login')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="username" class="form-label">Student ID</label>
                    <input type="text" placeholder="Student ID" class="form-control" name="username" aria-describedby="username">
                </div>
                <div class="mb-3">
                    <label for="Password1" class="form-label">Password</label>
                    <input type="password" placeholder="Password" class="form-control" name="password" aria-describedby="Password">
                </div>
                <div class="mb-3 form-check">
                    <input type="checkbox" class="form-check-input" id="exampleCheck1">
                    <label class="form-check-label" for="exampleCheck1">Remember me</label>
                </div>
                <?php echo $__env->make('website.session', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="mb-6 text-center">
                    <button type="submit" class="btn btn-dark" style="width:50%; background-color:#00264d" >login </button>
                </div>
            </form>

        </div>
    </div>
</div>

<script src="<?php echo e(asset('app.js')); ?>"></script>
</body>
</html><?php /**PATH /home/mostafa/projects/institute-freeLancer/resources/views/website/login.blade.php ENDPATH**/ ?>