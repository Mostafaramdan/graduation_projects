<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
<div class="container bootdey">
<div class="col-md-12 bootstrap snippets">
<div class="panel">
  
</div>
<div class="panel">
    <div class="panel-body">
    <!-- Newsfeed Content -->
    <!--===================================================-->
    <div class="media-block">
      <a class="media-left" href="#"></a>
      <div class="media-body">
        <div class="mar-btm">
            <a href="#" class="btn-link text-semibold media-heading box-inline">Sun, 11 Oct 2022</a>
        </div>
        <p>consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.</p>
        <div class="pad-ver">
          <div class="btn-group">
          </div>
        </div>
        <hr>

        <!-- Comments -->
        <div>

          <div class="media-block">
            
            <div class="media-body">
              <div class="mar-btm">
                <a href="#" class="btn-link text-semibold media-heading box-inline">Sun, 11 Oct 2022</a>
              </div>
              <p>Duis autem vel eum iriure dolor in hendrerit in vulputate ?</p>
              <div class="pad-ver">
                <div class="btn-group">
                </div>
                <div class="row ">
                    <div class="col-md-7  offset-md-1">
                        <div class="media-body">
                            <div class="mar-btm">
                                <a href="#" class="btn-link text-semibold media-heading box-inline">Sun, 11 Oct 2022</a>
                            </div>
                            <p>Duis autem vel eum iriure dolor in hendrerit in vulputate ?</p>
                        </div>
                    </div>
                    <div class="col-8 offset-md-1">
                        <input  placeholder="type your replay" class="form-control" id="typeComment"></textarea>
                    </div>
                    <div class="col-3">
                        <button class="btn w-25 center-text " style=" background-color:#00264d;color:#fff"> Send</button>
                    </div>
                </div>
              <hr>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--===================================================-->
    <!-- End Newsfeed Content -->


   
    <!--===================================================-->
    <!-- End Newsfeed Content -->
  </div>
</div>
</div>
</div><?php /**PATH /home/mostafa/projects/institute-freeLancer/resources/views/website/student/projects/components/updates.blade.php ENDPATH**/ ?>